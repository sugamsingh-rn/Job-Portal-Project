/**
 * 
 */
package com.jobportal.spring.dao;

/**
 * @author amayd
 *
 */
public interface UserDao {

}
